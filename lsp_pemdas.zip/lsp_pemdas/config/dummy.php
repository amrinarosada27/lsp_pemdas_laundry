<?php
$datapaket = [
    ["Cuci mobil kecil", "suzuki karimun, toyoyta agya, swift, ayla, jazz",40000],
    ["Cuci mobil sedang ", "Crv, Hrv,mobilio,civic",45000],
    ["Cuci mobil besar","Fortuner, pajero, robicorn",50000],
    ["Cuci mobil sangat besar","alpard,lexus, vellfire",55000]
];