<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <!-- MY Style -->
  <link rel="stylesheet" href="../assets/css/style.css">
  <title>Laundry</title>
</head>

<body>
  <?php include 'navbar.php' ?>

  <div class="container my-5">
    <div class="row">
      <div class="col-md-6 col-sm-12">
        <h1 class="mt-5">
          Selamat Datang <br>
          Aplikasi Laundry SMK ISFI
        </h1>
        <p>Melayani berbagai jenis cucian, selesai dengan tepat waktu. Rapi, bersih, dan wangi.</p>
        <a href="#paket" class="btn btn-sm btn-dark px-5 mt-3">Daftar Paket</a>
      </div>
      <div class="col-md-6 col-sm-12">
        <img src="../assets/img/washing-machine.png" alt="logo" class="img-fluid mx-auto d-block" width="400">
      </div>
    </div>
  </div>

  <section id="paket">
    <div class="container my-5">
      <h3 class="text-center mb-3">Daftar Paket</h3>

      <div class="row justify-content-center">
        <?php
        $datapaket = [
          ["Cuci mobil kecil", "suzuki karimun, toyoyta agya, swift, ayla, jazz",40000],
          ["Cuci mobil sedang ", "Crv, Hrv,mobilio,civic",45000],
          ["Cuci mobil besar","Fortuner, pajero, robicorn",50000],
          ["Cuci mobil sangat besar","alpard,lexus, vellfire",55000],
      ];

        foreach ($datapaket as $value) {
        ?>
          <div class="col-md-3 col-sm-12">
            <div class="card">
              <div class="card-body">
                <h4><?= $value[0] ?></h4>
                <p><?= $value[1] ?></p>
                <h5>Rp. <?= number_format($value[2], 0, '.', ',') ?></h5>
               
              </div>
            </div>
            <form action="transaksi.php" method="POST">
                  <input type="text" name="paket" value="<?= $value[0] ?>">
                  <input type="text" name="harga" value="<?= $value[2] ?>">
                  <button type="submit" class="btn btn-sm btn-dark w-100">Pilih Paket</button>
                </form>
          </div>
        <?php } ?>
      </div>
    </div>
  </section>

  <?php
  include 'footer.php';
  ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>