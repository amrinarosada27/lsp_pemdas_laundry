<section id="footer" class="bg-dark text-white py-2">
  <div class="container">
    <p class="text-center">&copy; 2022 Car Wash SMK ISFI</p>
  </div>
</section>