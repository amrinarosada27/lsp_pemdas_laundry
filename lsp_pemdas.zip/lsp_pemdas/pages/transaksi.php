<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <!-- MY Style -->
  <link rel="stylesheet" href="../assets/css/style.css">
  <title>Laundry</title>
</head>

<body>
  <?php
  include 'navbar.php';
  session_start();

  if (isset($_POST)) {
    $_SESSION['post'] = $_POST;
  }
  ?>

  <div class="container my-5">
    <form action="" method="POST">
      <div class="row">
        <div class="col-md-6 col-sm-12">
          <div class="mb-2">
            <label for="no-transaksi" class="form-label">No. Transaksi</label>
            <input type="text" id="no-transaksi" class="form-control">
          </div>
          <div class="mb-2">
            <label for="tanggal-transaksi" class="form-label">Tanggal Transaksi</label>
            <input type="date" id="tanggal-transaksi" class="form-control">
          </div>
          <div class="mb-2">
            <label for="nama-customer" class="form-label">Nama Customer</label>
            <input type="text" id="nama-customer" class="form-control">
          </div>
          <div class="mb-2">
            <label for="paket" class="form-label">Pilihan Paket</label>
            <input type="text" id="paket" class="form-control" value="<?= $_SESSION['post']['paket'] ?>" readonly>
          </div>
          <div class="mb-4">
            <label for="harga" class="form-label">Harga</label>
            <input type="text" id="harga" class="form-control" value="<?= $_SESSION['post']['harga'] ?>" readonly>
          </div>
          <div class="my-2">
            <button type="button" class="btn btn-sm btn-dark" onclick="hitungTotal()">Hitung Total Harga</button>
          </div>
        </div>
        <div class="col-md-6 col-sm-12">
          <div class="form-check">
            <div class="form-check">
              <input class="form-check-input" type="radio" id="satuhari" name="tambahan" value="0" required checked>
              <label class="form-check-label" for="tanpatambahan">
                Tidak ada tambahan - Rp. 0,-
              </label>
            </div>
          </div>
          <div class="form-check">
            <div class="form-check">
              <input class="form-check-input" type="radio" id="satuhari" name="tambahan" value="6000" required>
              <label class="form-check-label" for="tanpatambahan">
                Express 1 hari - Rp. 6000,-
              </label>
            </div>
          </div>
          <div class="form-check">
            <div class="form-check">
              <input class="form-check-input" type="radio" id="enamjam" name="tambahan" value="12000" required>
              <label class="form-check-label" for="tanpatambahan">
                Express 6 jam - Rp. 12.000,-
              </label>
            </div>
          </div>
          <div class="form-check">
            <div class="form-check">
              <input class="form-check-input" type="radio" id="tigajam" name="tambahan" value="18000" required>
              <label class="form-check-label" for="tanpatambahan">
                Express 3 jam - Rp. 18.000,-
              </label>
            </div>
          </div>
        </div>
      </div>
      <hr>
      <div class="mb-2">
        <label for="total-harga" class="form-label">Total Harga</label>
        <input type="text" id="total-harga" class="form-control" readonly>
      </div>
      <div class="row">
        <div class="col-6">
          <div class="mb-2">
            <label for="pembayaran" class="form-label">Pembayaran</label>
            <input type="text" id="pembayaran" class="form-control" required>
          </div>
          <button type="button" class="btn btn-sm btn-dark" onclick="hitungKembalian()">Hitung Kembalian</button>
        </div>
        <div class="col-6">
          <div class="mb-2">
            <label for="kembalian" class="form-label">Kembalian</label>
            <input type="text" id="kembalian" class="form-control" readonly>
          </div>
          <button type="button" class="btn btn-sm btn-dark w-100" onclick="simpan()">Simpan Transaksi</button>
        </div>
      </div>
    </form>
  </div>

  <?php
  include 'footer.php';
  ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  <script>
    // HITUNG TOTAL HARGA
    function hitungTotal() {
      let harga = parseInt(document.querySelector('#harga').value);
      let tambahan = parseInt(document.querySelector('input[name="tambahan"]:checked').value);
      let totalHarga = harga + tambahan;
      document.getElementById("total-harga").value = totalHarga;
    }

    // HITUNG KEMBALIAN
    function hitungKembalian() {
      let total = parseInt(document.getElementById("total-harga").value);
      let pembayaran = parseInt(document.getElementById("pembayaran").value);
      if (pembayaran >= total) {
        let kembalian = pembayaran - total;
        document.getElementById("kembalian").value = kembalian;
      } else {
        alert("Uang Tidak Cukup");
      }
    }

    // SIMPAN TRANSAKSI
    function simpan() {
      alert('Data Berhasil Disimpan');
      window.location = 'home.php';
    }
  </script>
</body>
</html>